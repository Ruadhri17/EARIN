from menu import run_menu

def main():
    run_menu()


if __name__ == "__main__":
    main()